# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class TruckingdatabaseItem(scrapy.Item):

    state = scrapy.Field()
    legal_name = scrapy.Field()
    doing_bussiness_as = scrapy.Field()
    carrier_operation = scrapy.Field()
    address = scrapy.Field()
    mailing_address = scrapy.Field()
    telephone = scrapy.Field()
    email = scrapy.Field()

    DOT_Number = scrapy.Field()
    Placardable_HM_Threshold = scrapy.Field()
    Passenger_Carrier_Threshold = scrapy.Field()
    MCS150_Date = scrapy.Field()
    Vehicle_Mileage_Traveled = scrapy.Field()
    Year_for_which_VMT_was_reported = scrapy.Field()
    Date_Added = scrapy.Field()
    FMCSA_State_office = scrapy.Field()
    Number_Of_Power_Units = scrapy.Field()
    Number_Of_Drivers = scrapy.Field()

    pass
