from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from ..items import TruckingdatabaseItem

class truckingdatabaseSpider(CrawlSpider):

    name = "truckingdatabase"

    start_urls = ["https://truckingdatabase.com/locations/VA/page:1"]

    def parse(self, response):
        
        links = response.css("td a::attr(href)").extract()

        for link in links:
            yield response.follow(link,callback=self.listing)

        next_page = response.css(".next a::attr(href)").extract_first()
        
        if next_page:
            yield response.follow(next_page,callback=self.parse)


    def listing(self,response):

        links = response.css(".property a::attr(href)").extract()

        for link in links:
            yield response.follow(link,callback=self.page)


        next_page = response.css(".next a::attr(href)").extract_first()
        
        if next_page:
            yield response.follow(next_page,callback=self.listing)


    def page(self,response):

        product = TruckingdatabaseItem()

        product["state"] = response.css("#main-content h2::text").extract_first()

        product["legal_name"] = response.xpath('//td[contains(text(),"Legal Name")]/following-sibling::td/text()').extract_first()

        product["doing_bussiness_as"] = response.xpath('//td[contains(text(),"Doing Business As")]/following-sibling::td/text()').extract_first()

        product["carrier_operation"] = response.xpath('//td[contains(text(),"Carrier Operation")]/following-sibling::td/text()').extract_first()


        product["mailing_address"] = response.xpath('//td[contains(text(),"Mailing Address")]/following-sibling::td/text()').extract()
        product["mailing_address"] = " ".join(product["mailing_address"])
        product["mailing_address"] =  product["mailing_address"].strip()
        product["mailing_address"] =  product["mailing_address"].replace("\r","")
        product["mailing_address"] =  product["mailing_address"].replace("\n","")
        product["mailing_address"] =  product["mailing_address"].replace("\t","")

        

        product["address"] = response.xpath('//td[contains(text(),"Address")]/following-sibling::td/text()').extract()
        product["address"] = " ".join(product["address"])
        product["address"] =  product["address"].strip()
        product["address"] =  product["address"].replace("\r","")
        product["address"] =  product["address"].replace("\n","")
        product["address"] =  product["address"].replace("\t","")


        if not product["mailing_address"] == product["address"]:
            temp = product["mailing_address"].split()
            save = temp[len(temp)-1]
            product["address"] =  product["address"].split(temp[len(temp)-1])[0]
            product["address"] = product["address"] + save

        product["telephone"] = response.xpath('//td[contains(text(),"Telephone")]/following-sibling::td/text()').extract_first()

        product["email"] = response.xpath('//td[contains(text(),"Email")]/following-sibling::td/a/text()').extract_first()


        product["DOT_Number"] = response.xpath('//td[contains(text(),"DOT Number")]/following-sibling::td/text()').extract_first()

        product["Placardable_HM_Threshold"] = response.xpath('//td[contains(text(),"Placardable HM threshold")]/following-sibling::td/text()').extract_first()

        product["Passenger_Carrier_Threshold"] = response.xpath('//td[contains(text(),"Passenger Carrier Threshold")]/following-sibling::td/text()').extract_first()

        product["MCS150_Date"] = response.xpath('//td[contains(text(),"MCS150 Date")]/following-sibling::td/text()').extract_first()

        product["Vehicle_Mileage_Traveled"] = response.xpath('//td[contains(text(),"Vehicle Mileage Traveled")]/following-sibling::td/text()').extract_first()

        product["Year_for_which_VMT_was_reported"] = response.xpath('//td[contains(text(),"Year for which VMT was reported")]/following-sibling::td/text()').extract_first()

        product["Date_Added"] = response.xpath('//td[contains(text(),"Date Added")]/following-sibling::td/text()').extract_first()

        product["FMCSA_State_office"] = response.xpath('//td[contains(text(),"FMCSA State office")]/following-sibling::td/text()').extract_first()

        product["Number_Of_Power_Units"] = response.xpath('//td[contains(text(),"Number Of Power Units")]/following-sibling::td/text()').extract_first()

        product["Number_Of_Drivers"] = response.xpath('//td[contains(text(),"Number Of Drivers")]/following-sibling::td/text()').extract_first()



        yield product